# BugHunter

BugHunter is a production-grade autonomous security scanning platform powered by an intelligent LangGraph engine.

## Installation

### Prerequisites
- Linux OS (Ubuntu 20.04+ recommended)
- Python 3.12+
- Go 1.22+

### Standard Installation
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
bughunter install
```

### Wheel Installation
```bash
pip install bughunter-1.0.0-py3-none-any.whl
bughunter install
```

### Docker
```bash
docker build --target full -t bughunter:latest .
docker run --rm -it bughunter:latest scan example.com --profile bug_bounty
```

## Quick Start

### 1. Verify Installation
```bash
bughunter doctor
```

### 2. Run First Scan
```bash
bughunter scan example.com --profile bug_bounty
```

### 3. Check Workspace & Reports
```bash
bughunter workspace list
```

## Core Commands

- `bughunter --help`: Display all available commands.
- `bughunter --version`: Print current version.
- `bughunter --install-completion`: Install shell completion.
- `bughunter doctor`: Diagnose system dependencies.
- `bughunter install`: Transactional dependency fetching.
- `bughunter verify`: Check installation integrity.
- `bughunter self-test`: Run internal unit verifications.
- `bughunter plugins`: List available capability-mapped plugins.
- `bughunter release-check`: Run the ultimate pre-release check.

## Profiles

Profiles configure the aggressiveness and plugins invoked:
- `minimal`: Passive recon.
- `bug_bounty`: Comprehensive standard scan.
- `stealth`: Passive scans bypassing active engagements.
- `full`: Exhaustive scanning.

## Architecture

BugHunter relies on a deterministic `LangGraph` topology to orchestrate and execute agents (Planner, Attacker, Correlator) based on declarative execution states.
All changes to the state are tracked via delta-appliers ensuring reproducible runs, while an overarching `RuntimeLayer` ensures operational integrity.

## Known Limitations

- Subdomain takeover capabilities (`subzy`) and secrets detection (`trufflehog`) require properly formatted configurations.
- Deep API scans may require robust hardware depending on OpenAPI schema complexity.

## License
MIT License.
