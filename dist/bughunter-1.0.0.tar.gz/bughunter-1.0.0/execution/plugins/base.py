from abc import ABC, abstractmethod
from typing import Tuple, Any, Mapping
from pydantic import BaseModel, ConfigDict

from schemas.runtime import Capability
from schemas.state import ExecutionState

class PluginMetadata(BaseModel):
    model_config = ConfigDict(frozen=True)
    name: str
    version: str
    description: str
    capabilities: Tuple[Capability, ...]
    supported_tools: Tuple[str, ...]
    minimum_version: str | None = None
    recommended_version: str | None = None

class PluginValidator(ABC):
    @abstractmethod
    def validate(self, state: ExecutionState, config: Mapping[str, Any]) -> bool:
        pass

class PluginParser(ABC):
    @abstractmethod
    def parse(self, stdout: str, stderr: str) -> Any:
        pass

    def build_metadata(self, parsed: Any) -> Mapping[str, Any]:
        """
        DEPRECATED: Default implementation for backward compatibility.
        Plugins should override this to return semantic metadata using execution.constants.
        """
        return {"new_findings": parsed}

class PluginRunner(ABC):
    @abstractmethod
    def build_command(self, state: ExecutionState, config: Mapping[str, Any]) -> Tuple[str, ...]:
        pass
        
    @abstractmethod
    def health_check(self) -> bool:
        pass

class ExecutionPlugin(PluginValidator, PluginParser, PluginRunner, ABC):
    @abstractmethod
    def metadata(self) -> PluginMetadata:
        pass
